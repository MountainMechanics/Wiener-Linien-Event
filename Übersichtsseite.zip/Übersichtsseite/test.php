<?php
require 'vendor/autoload.php';

$config = new \Doctrine\DBAL\Configuration();
$connectionParams = array (
    'dbname' => 'WienerLinienEventTool',
    'user' => 'root',
    'password' => '',
    'host' => 'localhost',
    'driver' => 'pdo_mysql',
);
$conn = \Doctrine\DBAL\DriverManager::getConnection($connectionParams, $config);
$sql = 'SELECT * FROM Participants';
$stmt = $conn->query($sql);

while ($row = $stmt->fetch()){
    echo $row['first_name']." ";
    echo $row['last_name']."
    <br>";

}